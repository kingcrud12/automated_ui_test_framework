# Promethee-Selenium

*[English version below | Version française plus bas]*

---

# 🇬🇧 English Description

**Promethee-Selenium** is a robust, Page Object Model (POM) based library for automated UI testing using Selenium and Pytest.

It is designed to streamline your end-to-end testing workflow by providing a structured architecture, ensuring your tests are maintainable, scalable, and easy to read.

## Features

-   **Page Object Model (POM)**: Enforces a clean separation between page interactions (locators, actions) and test logic (assertions, workflows).
-   **Interactive CLI**: A user-friendly command-line interface to guide you through project initialization and documentation.
-   **Scaffolding**: Quickly generate a production-ready project structure with `promethee-selenium init`.
-   **Built-in Utilities**: A rich set of helper functions for common Selenium actions (clicking, typing, waiting) powered by `selenium-ui-test-tool`.
-   **Environment Management**: Native support for managing test environments and credentials securely.
-   **Bilingual Support**: The CLI and documentation are available in both English and French.

## Installation

Install the package via pip:

```bash
pip install promethee-selenium
```

## Getting Started

1.  **Launch the CLI**:
    After installation, run the following command to access the interactive menu:
    ```bash
    promethee-selenium
    ```
    You will be prompted to select your language (English/French) and then choose an action.

2.  **Initialize a Project**:
    Select the **Init** option from the menu or run:
    ```bash
    promethee-selenium init
    ```
    This creates a standard directory layout:
    -   `scenarios/`: For your Page Object classes.
    -   `tests/`: For your Pytest test scripts.
    -   `data/`: For configuration files and test data.
    -   `utils/`: For project-specific utilities.
    -   `conftest.py`: Pytest configuration with pre-configured fixtures.

3.  **Run Your Tests**:
    Execute your tests using pytest:
    ```bash
    pytest tests/
    ```

## Documentation

To view the full documentation, select **Docs** from the CLI menu or run:
```bash
promethee-selenium docs
```

---

# 🇫🇷 Description Française

**Promethee-Selenium** est une librairie robuste basée sur le modèle Page Object Model (POM) pour l'automatisation de tests UI avec Selenium et Pytest.

Elle est conçue pour optimiser votre flux de travail de tests de bout en bout en fournissant une architecture structurée, garantissant que vos tests restent maintenables, évolutifs et lisibles.

## Fonctionnalités

-   **Page Object Model (POM)** : Impose une séparation claire entre les interactions de page (sélecteurs, actions) et la logique de test (assertions, scénarios).
-   **CLI Interactif** : Une interface en ligne de commande conviviale pour vous guider dans l'initialisation du projet et la consultation de la documentation.
-   **Génération de Projet** : Générez rapidement une structure de projet prête pour la production avec `promethee-selenium init`.
-   **Utilitaires Intégrés** : Un ensemble riche de fonctions d'aide pour les actions Selenium courantes (cliquer, écire, attendre), propulsé par `selenium-ui-test-tool`.
-   **Gestion d'Environnement** : Support natif pour gérer les environnements de test et les identifiants de manière sécurisée.
-   **Support Bilingue** : Le CLI et la documentation sont disponibles en anglais et en français.

## Installation

Installez le paquet via pip :

```bash
pip install promethee-selenium
```

## Démarrage Rapide

1.  **Lancez le CLI** :
    Après l'installation, exécutez la commande suivante pour accéder au menu interactif :
    ```bash
    promethee-selenium
    ```
    Il vous sera demandé de choisir votre langue (Anglais/Français) puis de choisir une action.

2.  **Initialisez un Projet** :
    Sélectionnez l'option **Init** dans le menu ou exécutez :
    ```bash
    promethee-selenium init
    ```
    Cela crée une structure de répertoires standard :
    -   `scenarios/` : Pour vos classes Page Object.
    -   `tests/` : Pour vos scripts de test Pytest.
    -   `data/` : Pour les fichiers de configuration et les données de test.
    -   `utils/` : Pour les utilitaires spécifiques au projet.
    -   `conftest.py` : Configuration Pytest avec des fixtures pré-configurées.

3.  **Lancez Vos Tests** :
    Exécutez vos tests avec pytest :
    ```bash
    pytest tests/
    ```

## Documentation

Pour consulter la documentation complète, sélectionnez **Docs** dans le menu du CLI ou exécutez :
```bash
promethee-selenium docs
```
